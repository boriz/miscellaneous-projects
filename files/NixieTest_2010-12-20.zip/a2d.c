 /*! \file a2d.c \brief Analog-to-Digital converter function library. */
//*****************************************************************************
//
// File Name	: 'a2d.c'
// Title		: Analog-to-digital converter functions
// Author		: Pascal Stang - Copyright (C) 2002
// Created		: 2002-04-08
// Revised		: 2002-09-30
// Version		: 1.1
// Target MCU	: Atmel AVR series
// Editor Tabs	: 4
//
// This code is distributed under the GNU Public License
//		which can be found at http://www.gnu.org/licenses/gpl.txt
//
//*****************************************************************************

#include <avr/io.h>
#include <avr/interrupt.h>

#include "global.h"
#include "a2d.h"
#include "timer.h"

// global variables
const uint8_t cVoltageSP = 200;	// Voltage set point
const uint8_t cVoltageMax = 220;	// Max safe voltage (stops PWM)
const uint8_t cPWM_Min = 8;	// Minimum pulse duration
const uint8_t cPWM_Max = 128;	// 32Mhz/2(divider)/256(TOP) = 62500Hz (16us)
const uint8_t cPID_MaxError = 30;	// Max PID error (mean we are way off the set point - turn PWM all way up/down)
const uint8_t cP_Gain = 15;	// Proportional term gain

//! Software flag used to indicate when
/// the a2d conversion is complete.
volatile unsigned char a2dCompleteFlag;

// functions

// initialize a2d converter
void a2dInit(void)
{
	sbi(ADCSRA, ADEN);				// enable ADC (turn on ADC power)
	a2dSetPrescaler(ADC_PRESCALE);	// set default prescaler
	a2dSetReference(ADC_REFERENCE);	// set default reference
	cbi(ADMUX, ADLAR);				// set to right-adjusted result

	sbi(ADCSRA, ADIE);				// enable ADC interrupts

	a2dCompleteFlag = FALSE;		// clear conversion complete flag
	sei();							// turn on interrupts (if not already on)
}

// turn off a2d converter
void a2dOff(void)
{
	cbi(ADCSRA, ADIE);				// disable ADC interrupts
	cbi(ADCSRA, ADEN);				// disable ADC (turn off ADC power)
}

// configure A2D converter clock division (prescaling)
void a2dSetPrescaler(unsigned char prescale)
{
	outb(ADCSRA, ((inb(ADCSRA) & ~ADC_PRESCALE_MASK) | prescale));
}

// configure A2D converter voltage reference
void a2dSetReference(unsigned char ref)
{
	sbi(ADCSRB, REFS2);
	outb(ADMUX, ((inb(ADMUX) & ~ADC_REFERENCE_MASK) | (ref<<6)));
}

// sets the a2d input channel
void a2dSetChannel(unsigned char ch)
{
	outb(ADMUX, (inb(ADMUX) & ~ADC_MUX_MASK) | (ch & ADC_MUX_MASK));	// set channel
}

// start a conversion on the current a2d input channel
void a2dStartConvert(void)
{
	sbi(ADCSRA, ADIF);	// clear hardware "conversion complete" flag 
	sbi(ADCSRA, ADSC);	// start conversion
}

// return TRUE if conversion is complete
u08 a2dIsComplete(void)
{
	return bit_is_set(ADCSRA, ADSC);
}

// Perform a 10-bit conversion
// starts conversion, waits until conversion is done, and returns result
unsigned short a2dConvert10bit(unsigned char ch)
{
	a2dCompleteFlag = FALSE;				// clear conversion complete flag
	outb(ADMUX, (inb(ADMUX) & ~ADC_MUX_MASK) | (ch & ADC_MUX_MASK));	// set channel
	sbi(ADCSRA, ADIF);						// clear hardware "conversion complete" flag 
	sbi(ADCSRA, ADSC);						// start conversion
	//while(!a2dCompleteFlag);				// wait until conversion complete
	//while( bit_is_clear(ADCSR, ADIF) );		// wait until conversion complete
	while( bit_is_set(ADCSRA, ADSC) );		// wait until conversion complete

	// CAUTION: MUST READ ADCL BEFORE ADCH!!!
	return (inb(ADCL) | (inb(ADCH)<<8));	// read ADC (full 10 bits);
}

// Perform a 8-bit conversion.
// starts conversion, waits until conversion is done, and returns result
unsigned char a2dConvert8bit(unsigned char ch)
{
	// do 10-bit conversion and return highest 8 bits
	return a2dConvert10bit(ch)>>2;			// return ADC MSB byte
}

//! Interrupt handler for ADC complete interrupt.
SIGNAL(SIG_ADC)
{
	
	uint8_t iVoltageActual;
	
	// Read the result
	iVoltageActual = (inb(ADCL) | (inb(ADCH)<<8)) >> 2;

	// Determine it's more than high lmit
	if (iVoltageActual > cVoltageMax)
	{
		// Turn off PWM
		timer1PWMBSet(0);
	}
	else
	{
		// Try to mimic simple PID loop. Actualy only P term should be enough
  		int16_t iError = cVoltageSP - iVoltageActual;
		uint8_t iPWM_SP;

		// Calculate P term and limit error overflow
  		if (iError > cPID_MaxError)
		{
    		iPWM_SP = cPWM_Max;
  		}
  		else if (iError < 0)
		{
			// Shortest pulse to maintain the voltage (overvoltage will shut it off when needed)
    		iPWM_SP = cPWM_Min;
  		}
  		else
		{
    		iPWM_SP = cP_Gain * iError;
  		}
  		
		// Limit PWM output
  		if(iPWM_SP > cPWM_Max)
		{
    		iPWM_SP = cPWM_Max;
  		}

		timer1PWMBSet(iPWM_SP);
	}


	// TODO: Kick the dog

	// set the a2d conversion flag to indicate "complete"
	a2dCompleteFlag = TRUE;

	// Delay before start next conversion
	//delay_us (100);	// 0.1 ms

	// Start next conversion
	a2dStartConvert();

}

