/*! \file rtc.c \brief Real-time clock function library. */
//*****************************************************************************
//
// File Name	: 'rtc.c'
// Title		: Real-time clock function library
// Author		: Pascal Stang - Copyright (C) 2002
// Created		: 5/10/2002
// Revised		: 9/30/2002
// Version		: 0.6
// Target MCU	: Atmel AVR Series
// Editor Tabs	: 4
//
// NOTE: This code is currently below version 1.0, and therefore is considered
// to be lacking in some functionality or documentation, or may not be fully
// tested.  Nonetheless, you can expect most functions to work.
//
// This code is distributed under the GNU Public License
//		which can be found at http://www.gnu.org/licenses/gpl.txt
//
//*****************************************************************************

#ifndef WIN32
	#include <avr/io.h>
	#include <avr/interrupt.h>
	#include <avr/pgmspace.h>
#endif

// TODO: For testing
#include <stdbool.h> 

#include "global.h"
// include timer support
#include "timer.h"

// include rtc header
#include "rtc.h"

// Program ROM constants
static char __attribute__ ((progmem)) MonthDayTable[] = {31,28,31,30,31,30,31,31,30,31,30,31};

// EEPROM Constant
static uint8_t __attribute__ ((eeprom)) EffectCur[] = {0,0,1,1,2,2,3,3,4,4,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5};
static uint8_t __attribute__ ((eeprom)) EffectPrev[] ={4,4,4,4,4,4,4,4,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}; 


// Global variables
// time registers
volatile RtcTimeType RtcTime;

// TODO: Change me to be an array of structures
u08 DispalyDigCur;
u08 DispalyDigPrev;


void rtcInit(void)
{
	// set up timer for RTC operation
	// initialize real-time registers
	RtcTime.tics15625 = 0;
	RtcTime.tics125 = 0;
	RtcTime.seconds = 0;
	RtcTime.minutes = 0;
	RtcTime.hours = 0;
	RtcTime.day = 1;
	RtcTime.month = 1;
	RtcTime.year = 2010;

	// attach service to real-time clock interrupt
	// rtcService() will be called at 4000000/256
	timerAttach(TIMER0OVERFLOW_INT, rtcService);

	DispalyDigCur = 1;
	DispalyDigPrev = 0;
}

void rtcService(void)
{
	// update real-time clock registers
	RtcTime.tics15625++;

	// check for overflows
	// 15625 tics per second

	if(RtcTime.tics15625 == 25)
	{
		// 15625/25=625Hz
		RtcTime.tics15625 = 0;
		RtcTime.tics625++;	// Increment 625Hz tics
		
		if (DispalyDigCur != DispalyDigPrev)
		{
			// Digit updated - run effect
			if (RtcTime.tics625 <= EffectCur[RtcTime.tics25])
			{
				outb(PORTA, DispalyDigCur);
			}
			else if (RtcTime.tics625 <= EffectPrev[RtcTime.tics25])
			{			
				outb(PORTA, DispalyDigPrev);
			}
			else
			{
				// Blank the indicator
				outb(PORTA, 0xFF);		
			}

		}
		
		if(RtcTime.tics625 == 5)
		{
			// 625/5=125Hz
			RtcTime.tics625 = 0;
			RtcTime.tics125++;	// Increment 125Hz tics


			if(RtcTime.tics125 == 5)
			{
				// 625/5=125Hz
				RtcTime.tics125 = 0;
				RtcTime.tics25++;	// Increment 25Hz tics

				if(RtcTime.tics25 == 25)
				{
					// 25/25=1Hz
					// One second
					RtcTime.tics25 = 0;
					RtcTime.seconds++;							// increment seconds

					// Increment digit every second
					DispalyDigPrev = DispalyDigCur;
					//if( (RtcTime.seconds % 2) == 0)
					//{
						DispalyDigCur++;
						if (DispalyDigCur > 9)
						{
							DispalyDigCur=0;
						}
					//}

					if(RtcTime.seconds > 59)					// check seconds overflow
					{
						RtcTime.seconds -= 60;
						RtcTime.minutes++;						// increment minutes
						if(RtcTime.minutes > 59)				// check minutes overflow
						{
							RtcTime.minutes -= 60;
							RtcTime.hours++;					// increment hours
							if(RtcTime.hours > 23)				// check hours overflow
							{
								RtcTime.hours -= 24;
								RtcTime.day++;					// increment days
								// check days overflow
								if(RtcTime.day == pgm_read_byte(&MonthDayTable[RtcTime.month-1]))
								{
									RtcTime.day = 1;
									RtcTime.month++;			// increment months
									if(RtcTime.month == 13)		// check months overflow
									{
										RtcTime.month = 1;
										RtcTime.year++;			// increment years
									}
								}
							}
						}
					}	// END Seconds

				}
			}
		}
	}
}

RtcTimeType* rtcGetTime(void)
{
	// return the real-time clock data
	return &RtcTime;
}

