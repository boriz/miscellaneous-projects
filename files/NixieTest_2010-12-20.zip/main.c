//----- Include Files ---------------------------------------------------------
#include <avr/io.h>		// include I/O definitions (port names, pin names, etc)
#include <avr/interrupt.h>	// include interrupt support

#include "global.h"		// include our global settings
#include "timer.h"		// include timer function library (timing, PWM, etc)
#include "a2d.h"		// include analog to digital library
#include "rtc.h"		// include real time clock library


//----- Begin Code ------------------------------------------------------------
int main(void)
{
	// At startup clock frequency divided by 8
	// Program clock prescaller to divide frequency by 1
	// Write CLKPCE 1 and other bits 0	
	outb(CLKPR, 0x80);
	// Write prescaler value (0) with CLKPCE = 0
	outb(CLKPR, 0);


	// ================ A/D ================
	// turn on and initialize A/D converter
	a2dInit();

	// configure a2d port (PORTB) as input
	// so we can receive analog signals
	cbi(DDRB, PB6);
	// make sure pull-up resistors are turned off
	cbi(PORTB, PB6);

		// set the a2d prescaler (clock division ratio)
	// - a lower prescale setting will make the a2d converter go faster
	// - a higher setting will make it go slower but the measurements
	//   will be more accurate
	// - other allowed prescale values can be found in a2d.h
	//a2dSetPrescaler(ADC_PRESCALE_DIV128);

	// set the a2d reference
	// - the reference is the voltage against which a2d measurements are made
	// - other allowed reference values can be found in a2d.h
	//a2dSetReference(ADC_REFERENCE_256V);

	a2dSetChannel(ADC_CH_ADC9);
	
	a2dStartConvert();


	// ================ TIMERS ================
	// initialize the timer system
	timerInit();

	// here's an example of using the timer library to do
	// pulse-width modulation or PWM.  PWM signals can be created on
	// any output compare (OCx) pin.  See your processor's data sheet
	// for more information on which I/O pins have output compare
	// capability.

	// set the OC1x port pins to output
	// We need to do this so we can see and use the PWM signal
	// ** these settings are correct for most processors, but not for all
	cbi(PORTB, PB3);
	sbi(DDRB, PB3);	

	// initialize timer1 for PWM output
	// - you may use 8,9, or 10 bit PWM resolution
	timer1PWMInit(8);

	// turn on the channel A PWM output of timer1
	// - this signal will come out on the OC1A I/O pin
	timer1PWMBOn();

	// set the duty cycle of the channel B output
	timer1PWMBSet(0);

	// example: wait for 10sec
	//timerPause(10000);

	// now turn off all PWM on timer1
	//timer1PWMOff();


	// ================ DIGITS UPDATE ================
	// Configure Port A to be output (Digits update)
	DDRA = 0xFF;

	rtcInit();

	while(1)
	{
	}


	return 0;
}
