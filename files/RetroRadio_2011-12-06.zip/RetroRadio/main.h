//*****************************************************************************
// Title		: MSP430 AU file player - main program
// Author		: Boris Cherkasskiy
// Created		: 2011-09-07
//
// This code is distributed under the GNU Public License
// which can be found at http://www.gnu.org/licenses/gpl.txt
//*****************************************************************************


#ifndef MAIN_H
#define MAIN_H

//#include "msp430x20x3.h"
#include "msp430G2231.h"

#endif
