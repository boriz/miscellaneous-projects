//*****************************************************************************
// Boris Cherkasskiy: Fast and simple circular FIFO buffer implementation
// It based on the serial communication example from microchip
// http://www.microchipc.com/sourcecode/#interrupt_uart
//*****************************************************************************
 
 
/*
 * Distributed by www.microchipC.com - one of the web's largest
 * repositories of C source code for Microchip PIC micros.
 *
 * ser.c
 *
 * Interrupt Driven Serial Routines with Circular FIFO
 * Copyright (c) 2006, Regulus Berdin
 * All rights reserved. 
 * 
 * Permission is hereby granted, free of charge, to any person
 * obtaining a copy of this software and associated documentation
 * files (the "Software"), to deal in the Software without
 * restriction, including without limitation the rights to use,
 * copy, modify, merge, publish, distribute, sublicense, and/or
 * sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following
 * conditions:
 * 
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software. 
*/


//----- Include Files ---------------------------------------------------------
#include "fifo.h"


unsigned char arFIFO_Buf[FIFO_BUFFER_SIZE];
volatile unsigned char ucIndexIn, ucIndexOut;


//----- Begin Code ------------------------------------------------------------

void fifo_init(void)
{
    ucIndexIn = ucIndexOut = 0;
}

char fifo_in_ready(void)
{
    return (((ucIndexIn + 1) & FIFO_MASK) != ucIndexOut) ;
}

void fifo_in(unsigned char ucByte)
{        
    arFIFO_Buf[ucIndexIn] = ucByte;
    ucIndexIn = (ucIndexIn + 1) & FIFO_MASK;
}

char fifo_out_ready(void)
{
    return (ucIndexIn != ucIndexOut);
}

unsigned char fifo_out()
{
    unsigned char ucByte;
    
    ucByte = arFIFO_Buf[ucIndexOut];
    ++ucIndexOut;
    ucIndexOut &= FIFO_MASK;
    
    return ucByte;
}
