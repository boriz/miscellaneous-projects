//*****************************************************************************
// Boris Cherkasskiy: Fast and simple circular FIFO buffer implementation
// It based on the serial communication example from microchip
// http://www.microchipc.com/sourcecode/#interrupt_uart
//*****************************************************************************


/*
 * ser.h
 *
 * Interrupt Driven Serial Routines with Circular FIFO
 * Copyright (c) 2006, Regulus Berdin
 * All rights reserved. 
 * 
 * Permission is hereby granted, free of charge, to any person
 * obtaining a copy of this software and associated documentation
 * files (the "Software"), to deal in the Software without
 * restriction, including without limitation the rights to use,
 * copy, modify, merge, publish, distribute, sublicense, and/or
 * sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following
 * conditions:
 * 
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
*/

 
#ifndef FIFO_H_
#define FIFO_H_

/* Valid buffer size value are only power of 2 (ex: 2,4,...) */
#define FIFO_BUFFER_SIZE 16
		
#define FIFO_MASK (FIFO_BUFFER_SIZE - 1)

void fifo_init (void);
char fifo_in_ready(void);
void fifo_in (unsigned char ucByte);
char fifo_out_ready(void);
unsigned char fifo_out();

#endif
