//*****************************************************************************
//
// Title		: AU file parser - header file
// Author		: Boris Cherkasskiy
// Created		: 2011-08-05
//
// This code is distributed under the GNU Public License
// which can be found at http://www.gnu.org/licenses/gpl.txt
//*****************************************************************************


#ifndef AU_H
#define AU_H

#include <stdbool.h>

bool au_Init(void);
bool au_ReadHeader(void);

unsigned char au_MMC_ReadAbsoluteAddress (unsigned long lAddress);
unsigned char au_MMC_ReadAbsoluteAddressNext (void);

unsigned char au_GetSample (unsigned long lSampleNumber);
unsigned char au_GetSampleNext (void);

unsigned long au_ReadNextLong (void);

#endif
