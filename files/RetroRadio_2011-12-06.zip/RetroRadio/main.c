//*****************************************************************************
// Title		: MSP430 AU file player - main program
// Author		: Boris Cherkasskiy
// Created		: 2011-09-07
//
// This code is distributed under the GNU Public License
// which can be found at http://www.gnu.org/licenses/gpl.txt
//*****************************************************************************


//----- Include Files ---------------------------------------------------------
#include "main.h"
#include "au_file.h"
#include "fifo.h"

unsigned char ucCounter_SampleRate;
unsigned char ucCurrentSample;


//----- Begin Code ------------------------------------------------------------

// Main program
int main(void)
{
	// Stop watchdog timer
	WDTCTL = WDTPW + WDTHOLD;             
      
	// Load RSEL/DCO constants
	BCSCTL1 = XT2OFF + RSEL3 + RSEL2 + RSEL1 + RSEL0;  // 15.25MHz => RSEL=15, XT2OFF=1
	DCOCTL = DCO2; // 16Mhz, DCO=4, MOD=0    

	// Configure pins to output direction
	// P1.0 (Red LED) - error/sample toggle
	// P1.1 - spare
	// P1.3 - SD card power supply (to reset the card)
	P1DIR = BIT0 + BIT1 + BIT3;  
  
	// Reset SD card
	P1OUT &= ~BIT3;
	__delay_cycles(1600000);	// 100ms
	P1OUT |= BIT3;
	__delay_cycles(1600000);	// 100ms
   
	// Configure P1.2 as PWM output
	P1SEL = BIT2;    //p1.2 in TA mode PWM
	P1DIR |= BIT2;    //p1.2 output
  
  
	// Time A PWM MODE
	// 0-output 
	// 1-set
	// 2-toggle/reset 
	// 3-set/reset 
	// 4-toggle 
	// 5-reset
	// 6-toggle/set 
	// 7-reset/set
	TACCTL1 = OUTMOD_3 + CCIE;
  
	// PWM Period, 16 bits,//use period-1 for MC mode 1-up counter.
	TACCR0 = 0xFF;                           
  
	// TACCR1 - PWM duty cycle
	TACCR1 = 0;                              
  
	// Timer A mode
	// 0-stop
	// 1-up
	// 2-contin
	// 3-up/down
	// Select SMCLK source
	TACTL = TASSEL_2 + MC_1 + ID_0;          
      
  
	// 00 Watchdog clock source /32768
	// 01 Watchdog clock source /8192
	// 10 Watchdog clock source /512
	// 11 Watchdog clock source /64
	WDTCTL = WDTPW + WDTTMSEL + WDTCNTCL + WDTIS1;    // Set Watchdog Timer interval to 512
	IE1 |= WDTIE;                               // Enable WDT interrupt

 
	// Read au file header
	if (!au_Init() || !au_ReadHeader())
	{
		// flash error LED forever
		for (;;)
		{  		
			P1OUT |= BIT0;
			__delay_cycles(3200000);	// 200ms
			P1OUT &= ~BIT0;
			__delay_cycles(3200000);	// 200ms
		}
	}

	// No errors
	// Read first sample and add it to the fifo
	fifo_init();
	fifo_in(au_GetSample(0));
      
      
	// Enable interrupts
	_BIS_SR(GIE); 
      
        
	// Forever loop
	for (;;)
	{  
  		// Can we fit another sample to the fifo?
  		if (fifo_in_ready())
  		{
      		// Read next sample - it will automatically jump to the first sample if needed
      		fifo_in(au_GetSampleNext());
  		}
		else
  		{
  			// Nothing to do - sleep
  			LPM0;
  		}
  	}
}	// End main


// Watchdog Timer interrupt service routine
#pragma vector=WDT_VECTOR
__interrupt void watchdog_timer(void)
{	
	// Exit low power mode 
	LPM0_EXIT;
	
	// P1.0 - Toggle every sample period for frequency fine-tuning 
	P1OUT ^= BIT0;
	
    // Is there new sample avialible?
    if (fifo_out_ready())
    {
    	// Get the next sample
      	ucCurrentSample = fifo_out();
    }
}


// TimerA interrupt service routine
#pragma vector=TIMERA1_VECTOR
__interrupt void timer_taccr1(void)
{
  switch (TAIV)         // Efficient switch-implementation
  {
    case  TAIV_NONE:
      break;
      
    case  TAIV_TACCR1: // Compare match interrupt (TACCR1 - duty cycle)
      	// Exit low power mode 
  		LPM0_EXIT;    
        
        // Update PWM register with latest sample
        TACCR1 = ucCurrentSample;    
      break;
      
    default:
      break;
  }  
}

// Not used - just reti
#pragma vector=PORT1_VECTOR
__interrupt void port1(void)
{
}

// Not used - just reti
#pragma vector=PORT2_VECTOR
__interrupt void port2(void)
{
}

// Not used - just reti
#pragma vector=USI_VECTOR
__interrupt void usi(void)
{
}

// Not used - just reti
#pragma vector=NMI_VECTOR
__interrupt void nmi(void)
{
  IFG1 = 0x00;
}
