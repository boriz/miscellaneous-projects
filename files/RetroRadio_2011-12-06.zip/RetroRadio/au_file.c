//*****************************************************************************
// Title		: MSP430 AU file player - AU file parser 
// Author		: Boris Cherkasskiy
// Created		: 2011-09-07
//
// This code is distributed under the GNU Public License
// which can be found at http://www.gnu.org/licenses/gpl.txt
//*****************************************************************************


//----- Include Files ---------------------------------------------------------
#include "au_file.h"
#include "mmc.h"


// structure to hold current MMC address
struct sMMC_Address {
  unsigned long lBlockStartAddress;
  unsigned int iOffsetInsideBlock;
  unsigned long lCardSize;
} MMC_Address;
  

// structure to hold au file header information
struct sHeaderAu {
  unsigned long lDataOffsetBytes;
  unsigned long lDataSizeBytes;
  unsigned long lSampleNumber;
} HeaderAu;


//----- Begin Code ------------------------------------------------------------

bool au_Init(void)
{
  // Init SPI
  MMC_initSPI();

  // Initialize Sd card
  if (initMMC() != MMC_SUCCESS)
  {
    return false;
  }

  // Clear structures
//  MMC_Address.lBlockStartAddress = 0;
//  MMC_Address.iOffsetInsideBlock = 0;
//  MMC_Address.lCardSize = 0;
//  HeaderAu.lDataOffsetBytes = 0;
//  HeaderAu.lDataSizeBytes = 0;
  
  // Read card size for future use
  MMC_Address.lCardSize =  MMC_ReadCardSize();
  
  return (MMC_Address.lCardSize > 0);
} 


bool au_ReadHeader(void)
{ 
  unsigned long lTemp;
  
  // Read magic number 0x2e736e64 (.snd)
  lTemp = (unsigned long)au_MMC_ReadAbsoluteAddress(0) << 24;
  lTemp += (unsigned long)au_MMC_ReadAbsoluteAddressNext() << 16;
  lTemp += (unsigned long)au_MMC_ReadAbsoluteAddressNext() << 8;
  lTemp += (unsigned long)au_MMC_ReadAbsoluteAddressNext();
  if (lTemp != 0x2E736E64)
  {
    return false;
  }
  
  // Read first sample offset (bytes)
  HeaderAu.lDataOffsetBytes = au_ReadNextLong();
  
  // Read data/sampple size (bytes)
  HeaderAu.lDataSizeBytes = au_ReadNextLong();
    
  // Confirm it's aligned with MMC card size
  if ((HeaderAu.lDataSizeBytes <= 0) || ((HeaderAu.lDataSizeBytes + HeaderAu.lDataOffsetBytes) >= MMC_Address.lCardSize) )
  {
    return false;
  }
  
  // Read encoding. Should be 2: 8-bit linear PCM
  if (au_ReadNextLong() != 2)
  {
    return false;
  }
  
  // Read sample rate. Should be 41400 (32000?)

  if (au_ReadNextLong() != 32000)
  {
    return false;
  }
  
  // Read number of channels (1)
  if (au_ReadNextLong() != 1)
  {
    return false;
  }
  
  return true;
}

unsigned long au_ReadNextLong (void)
{
	  unsigned long lTemp;
  
  // Read magic number 0x2e736e64 (.snd)
  lTemp = (unsigned long)au_MMC_ReadAbsoluteAddressNext() << 24;
  lTemp += (unsigned long)au_MMC_ReadAbsoluteAddressNext() << 16;
  lTemp += (unsigned long)au_MMC_ReadAbsoluteAddressNext() << 8;
  lTemp += (unsigned long)au_MMC_ReadAbsoluteAddressNext();
  
  return lTemp;
}


unsigned char au_MMC_ReadAbsoluteAddress (unsigned long lAddress)
{  
  // Verify we are not trying to read outside of the MMC card size
  if (lAddress >= MMC_Address.lCardSize)
  {
    // Return 0, reset addresses
    MMC_Address.lBlockStartAddress = 0;
    MMC_Address.iOffsetInsideBlock = 0;
    return 0;
  }
  
  // Block start offset
  MMC_Address.lBlockStartAddress = (lAddress / 512) * 512;
     
  // Offset inside the block
  MMC_Address.iOffsetInsideBlock = lAddress - MMC_Address.lBlockStartAddress;
     
  // Read byte
  // TODO: Evaluate MMC errors
  mmcUnmountBlock();
  mmcMountBlock(MMC_Address.lBlockStartAddress); 
  return mmcReadByte();
}

unsigned char au_MMC_ReadAbsoluteAddressNext (void)
{     
  // Should we jump to the next block?    
  if(MMC_Address.iOffsetInsideBlock >= 511)
  {
    // Jump to the next block              
    return au_MMC_ReadAbsoluteAddress(MMC_Address.lBlockStartAddress + 512);
  }
  else
  {
    // Read next byte within the current block
    // Don't read beyound the card size
    if((MMC_Address.lBlockStartAddress + MMC_Address.iOffsetInsideBlock) >= MMC_Address.lCardSize)
    {
      // Reach card size limit - reset
      MMC_Address.lBlockStartAddress = 0;
      MMC_Address.iOffsetInsideBlock = 0;
      return 0;
    }
    else
    {
      // Increment current address counter and read the next byte
     MMC_Address.iOffsetInsideBlock++;
     return mmcReadByte();
    }    
  }
  
  // Should never get here
}

unsigned char au_GetSample (unsigned long lSampleNumber)
{
  // Don't try to read beyound the file
  if ((HeaderAu.lDataOffsetBytes + lSampleNumber) >= HeaderAu.lDataSizeBytes)
  {
    // Outside of the file - return 0, reset sample counter
    HeaderAu.lSampleNumber = 0;
    return 0;
  }
  else
  {
    // Read absolute byte
    HeaderAu.lSampleNumber = lSampleNumber;
    return (128 + au_MMC_ReadAbsoluteAddress(HeaderAu.lDataOffsetBytes + lSampleNumber));
  }
}


unsigned char au_GetSampleNext (void)
{
  // Don't read beyound the file size
  if ((HeaderAu.lDataOffsetBytes + HeaderAu.lSampleNumber) >= HeaderAu.lDataSizeBytes)
  {
    // Not an error - just jump to the first sample
    HeaderAu.lSampleNumber = 0;
    return (128 + (int)au_GetSample(0));
  }
  else
  {
    // Read next sample
    HeaderAu.lSampleNumber++;
    return (128 + (int)au_MMC_ReadAbsoluteAddressNext());
  }
  
  // Should never get here
}


